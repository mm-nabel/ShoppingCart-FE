import React from 'react';

const About = () => {
    return (
        <div className="about">
            This is about
        </div>
    )
}

export default About;